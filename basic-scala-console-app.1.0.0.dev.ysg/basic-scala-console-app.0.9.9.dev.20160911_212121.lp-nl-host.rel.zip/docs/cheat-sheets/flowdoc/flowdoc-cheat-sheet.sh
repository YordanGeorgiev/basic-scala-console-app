source
https://www.flowdock.com/help/chat_input

#how-to comment source code 
def source_code
  is("nice").to_look_at
end

This [link](http://google.com) is amazing.
